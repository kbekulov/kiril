REINSTATES — VISUAL STUDIO SOURCE PACKAGE

Requirements
- Visual Studio with support for .NET 10.
- .NET 10 SDK and internet access for the first NuGet package restore.

Open and build
1. Extract this ZIP to a local folder.
2. Open Reinstates.sln in Visual Studio.
3. Set Reinstates as the startup project.
4. Build the solution; Visual Studio restores the NuGet dependencies.
5. Run the automated tests through Test Explorer if desired.

Run
Set these command-line arguments in the Reinstates debug launch profile,
replacing the example paths with your actual absolute paths:

"C:\Reports\Input" "C:\Reports\Output\reinstates.duckdb" "C:\Projects\Reinstates\appsettings.json"

Alternatively, from a terminal in this extracted solution folder:

dotnet run --project src/Reinstates -- "C:\Reports\Input" "C:\Reports\Output\reinstates.duckdb" "appsettings.json"

The first argument is required. The second defaults to output/reinstates.duckdb.
The third is optional; without it, built-in defaults are used. appsettings.json
is loaded only when its path is explicitly supplied.

Configuration
Edit appsettings.json to change wildcard filenames, allowed partner IDs,
number formats, thresholds, and the database memory budget. Defaults are also
centralized in src/Reinstates/AppOptions.cs.

Input and processing
- Exactly two *0463*.csv files, one *0380*.csv, and one *0458*.csv.
- UTF-8 CSV files with headers; defaults use commas as field separators and
  periods as decimal separators. Quoted fields and multiline cells are supported.
- The 0463 files are appended by column name, preserving duplicate rows.
- 0380 headers are renamed as requested. Remove ABS(Commission) < 0.001.
  Then round Commission + FX Commission - Amount to two decimals and remove
  rows where the rounded result has an absolute value below 0.001.
  Both signs are handled equally. Midpoint rounding is away from zero.
  Commission is saved as DOUBLE after decimal calculations and filtering.
- 0458 keeps exact Partner ID matches from the allowlist, initially RU999 and
  FR999, ignoring casing and surrounding spaces.
- Missing or invalid numeric values stop the run; they are not silently ignored.
- The source CSV files are not modified. A failed run rolls back all changes.

Output tables in the DuckDB database
raw.file_0463_a, raw.file_0463_b, raw.file_0380, raw.file_0458
processed.merged_0463, processed.reinstates_0380, processed.partners_0458
processed.allowed_partners

Future rules
Add an IPipelineStep implementation under src/Reinstates/Processing and register
it in ProcessingPipeline.cs. Steps share one database connection and transaction.

Package contents
Only solution/project files, C# source, configuration, dependency lock files,
tests and this guide are included. Build outputs, downloaded packages, sample
data, generated databases, logs and temporary files are omitted.
