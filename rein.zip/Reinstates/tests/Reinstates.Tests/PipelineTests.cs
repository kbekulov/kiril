using System.Globalization;

namespace Reinstates.Tests;

public sealed class PipelineTests
{
    [Fact]
    public void ImportsFourSourcesAndCreatesSeparateProcessedTables()
    {
        using var workspace = new TestWorkspace();
        workspace.Write("a_0463.csv", "MTCN,Partner ID,Description\n000001,RU999,Original\n000001,RU999,Original\n");
        workspace.Write("b_0463.csv", "Partner ID,MTCN,Extra\nFR999,000002,Other schema\n");
        workspace.Run();
        Assert.Equal(2, workspace.Count("raw.file_0463_a"));
        Assert.Equal(1, workspace.Count("raw.file_0463_b"));
        Assert.Equal(1, workspace.Count("raw.file_0380"));
        Assert.Equal(3, workspace.Count("raw.file_0458"));
        Assert.Equal(3, workspace.Count("processed.merged_0463"));
        Assert.Equal(2, workspace.Count("processed.partners_0458"));
        Assert.Equal(["000002", "FR999", "<NULL>", "Other schema"], workspace.Query(
            "SELECT MTCN, \"Partner ID\", Description, Extra FROM processed.merged_0463 WHERE MTCN = '000002'")[0]);
        Assert.Equal(["LE Name", "MTCN (Reinstates)", "Commission", "FX Commission", "Amount", "Extra"],
            workspace.Query("DESCRIBE processed.reinstates_0380").Select(row => row[0]));
        Assert.Equal(["DOUBLE", "DECIMAL(38,12)", "DECIMAL(38,12)"], workspace.Query(
            "SELECT typeof(Commission), typeof(\"FX Commission\"), typeof(Amount) FROM processed.reinstates_0380")[0]);
        Assert.Equal(["000001", "preserve me"], workspace.Query(
            "SELECT \"MTCN (Reinstates)\", Extra FROM processed.reinstates_0380")[0]);
        Assert.Contains(workspace.Query("DESCRIBE raw.file_0380"), row => row[0] == "*** LE Name ***");
    }

    [Theory]
    [InlineData("0", false)]
    [InlineData("-0", false)]
    [InlineData("0.0009", false)]
    [InlineData("-0.0009", false)]
    [InlineData("0.000999999999", false)]
    [InlineData("-0.000999999999", false)]
    [InlineData("0.001", true)]
    [InlineData("-0.001", true)]
    [InlineData("0.009", true)]
    [InlineData("-0.009", true)]
    [InlineData("10", true)]
    [InlineData("-10", true)]
    public void CommissionUsesStrictAbsolutePointZeroZeroOneThreshold(string commission, bool keep)
    {
        using var workspace = new TestWorkspace();
        workspace.Write0380(commission, "2", "0");
        workspace.Run();
        Assert.Equal(keep ? 1 : 0, workspace.Count("processed.reinstates_0380"));
    }

    [Theory]
    [InlineData("0", false)]
    [InlineData("0.001", false)]
    [InlineData("-0.001", false)]
    [InlineData("0.004", false)]
    [InlineData("-0.004", false)]
    [InlineData("0.004999999999", false)]
    [InlineData("-0.004999999999", false)]
    [InlineData("0.005", true)]
    [InlineData("-0.005", true)]
    [InlineData("0.009", true)]
    [InlineData("-0.009", true)]
    [InlineData("0.01", true)]
    [InlineData("-0.01", true)]
    [InlineData("-5", true)]
    public void DifferenceIsRoundedToTwoPlacesBeforeAbsoluteFiltering(string difference, bool keep)
    {
        using var workspace = new TestWorkspace();
        var amount = 1m - decimal.Parse(difference, CultureInfo.InvariantCulture);
        workspace.Write0380("1", "0", amount.ToString(CultureInfo.InvariantCulture));
        workspace.Run();
        Assert.Equal(keep ? 1 : 0, workspace.Count("processed.reinstates_0380"));
    }

    [Fact]
    public void DecimalArithmeticPreservesExactHalfCentBoundaries()
    {
        using var workspace = new TestWorkspace();
        workspace.Write0380("0.1", "0.2", "0.295");
        workspace.Run();
        Assert.Equal(1, workspace.Count("processed.reinstates_0380"));
    }

    [Fact]
    public void PartnersUseExactCaseInsensitiveTrimmedMembershipWithoutDuplicatingRows()
    {
        using var workspace = new TestWorkspace();
        workspace.Write("partners_0458.csv", "Partner ID,MTCN\n RU999 ,01\nfr999,02\nXXRU999,03\nRU999XX,04\n,05\nUS999,06\n");
        workspace.Run(new AppOptions { AllowedPartnerIds = ["ru999", " RU999 ", "FR999"] });
        Assert.Equal(2, workspace.Count("processed.partners_0458"));
        Assert.Equal(2, workspace.Count("processed.allowed_partners"));
        Assert.Equal(["01", "02"], workspace.Query("SELECT MTCN FROM processed.partners_0458 ORDER BY MTCN").Select(row => row[0]));
    }

    [Fact]
    public void EmptyPartnerListKeepsNoRows()
    {
        using var workspace = new TestWorkspace();
        workspace.Run(new AppOptions { AllowedPartnerIds = [] });
        Assert.Equal(0, workspace.Count("processed.partners_0458"));
    }

    [Theory]
    [InlineData("1,234.56", ".", ",")]
    [InlineData("1.234,56", ",", ".")]
    [InlineData("1 234,56", ",", " ")]
    [InlineData("1234.56", ".", "")]
    public void ParsesExplicitNumberFormats(string number, string decimalSeparator, string thousandsSeparator)
    {
        using var workspace = new TestWorkspace();
        workspace.Write0380(number, "0", "0");
        workspace.Run(new AppOptions { DecimalSeparator = decimalSeparator, ThousandsSeparator = thousandsSeparator });
        Assert.Equal("1234.56", workspace.Query("SELECT Commission FROM processed.reinstates_0380")[0][0]);
    }

    [Theory]
    [InlineData("")]
    [InlineData("not a number")]
    [InlineData("NaN")]
    [InlineData("Infinity")]
    [InlineData("1,23.45")]
    [InlineData("0.0009999999999")]
    [InlineData("100000000000000000000000000")]
    [InlineData("1e-3")]
    public void InvalidNumbersFailInsteadOfSilentlyDroppingRows(string commission)
    {
        using var workspace = new TestWorkspace();
        workspace.Write0380(commission, "0", "0");
        var exception = Assert.Throws<InvalidDataException>(() => workspace.Run());
        Assert.Contains("Commission", exception.Message);
        Assert.Equal(0, workspace.Count("information_schema.tables"));
    }

    [Theory]
    [InlineData("bad", "0")]
    [InlineData("0", "bad")]
    public void AlsoValidatesFxCommissionAndTotalEvenOnRowsThatWouldBeFilteredOut(string fx, string total)
    {
        using var workspace = new TestWorkspace();
        workspace.Write0380("0", fx, total);
        Assert.Throws<InvalidDataException>(() => workspace.Run());
    }

    [Fact]
    public void RepeatedRunReplacesResultsAndLateFailureRollsBackEveryDataset()
    {
        using var workspace = new TestWorkspace();
        workspace.Run();
        workspace.Run();
        Assert.Equal(2, workspace.Count("processed.merged_0463"));
        workspace.Write("a_0463.csv", "MTCN,Partner ID\n999999,RU999\n");
        workspace.Write0380("123", "0", "0");
        workspace.Write("partners_0458.csv", "Wrong Header,MTCN\nRU999,000001\n");
        Assert.Throws<InvalidDataException>(() => workspace.Run());
        Assert.Equal("000001", workspace.Query("SELECT MTCN FROM raw.file_0463_a")[0][0]);
        Assert.Equal("1", workspace.Query("SELECT Commission FROM processed.reinstates_0380")[0][0]);
        Assert.Equal(2, workspace.Count("processed.partners_0458"));
    }

    [Fact]
    public void CancellationAfterImportRollsBackTheRun()
    {
        using var workspace = new TestWorkspace();
        workspace.Run();
        workspace.Write("a_0463.csv", "MTCN,Partner ID\n999999,RU999\n");
        using var cancellation = new CancellationTokenSource();
        Assert.Throws<OperationCanceledException>(() => workspace.Run(log: message =>
        {
            if (message.StartsWith("Processing 0380", StringComparison.Ordinal))
                cancellation.Cancel();
        }, token: cancellation.Token));
        Assert.Equal("000001", workspace.Query("SELECT MTCN FROM raw.file_0463_a")[0][0]);
    }

    [Fact]
    public void HeaderOnlyFilesProduceEmptyTables()
    {
        using var workspace = new TestWorkspace();
        workspace.Write("a_0463.csv", "MTCN,Partner ID\n");
        workspace.Write("b_0463.csv", "Partner ID,MTCN\n");
        workspace.Write("reinstates_0380.csv", "LE Name,MTCN,Commission,FX Commission,Total\n");
        workspace.Write("partners_0458.csv", "Partner ID,MTCN\n");
        workspace.Run();
        Assert.Equal(0, workspace.Count("processed.merged_0463"));
        Assert.Equal(0, workspace.Count("processed.reinstates_0380"));
        Assert.Equal(0, workspace.Count("processed.partners_0458"));
    }

    [Fact]
    public void HandlesBomUnicodeHeadersQuotedCommasQuotesAndMultilineCells()
    {
        using var workspace = new TestWorkspace();
        workspace.Write("reinstates_0380.csv", "\uFEFF*** LE\u00a0\u200bName ***,MTCN,Commission,FX Commission,Total,Notes\r\n" +
            "LE,000123,1,0,0,\"comma, quote \"\"here\"\"\r\nnext line\"\r\n");
        workspace.Run();
        Assert.Equal(["LE", "000123", "comma, quote \"here\"\r\nnext line"], workspace.Query(
            "SELECT \"LE Name\", \"MTCN (Reinstates)\", Notes FROM processed.reinstates_0380")[0]);
    }

    [Fact]
    public void CustomDelimiterIsAppliedConsistently()
    {
        using var workspace = new TestWorkspace();
        workspace.Write("a_0463.csv", "MTCN;Partner ID\n01;RU999\n");
        workspace.Write("b_0463.csv", "MTCN;Partner ID\n02;FR999\n");
        workspace.Write("reinstates_0380.csv", "LE Name;MTCN;Commission;FX Commission;Total\nLE;01;1,23;0;0\n");
        workspace.Write("partners_0458.csv", "Partner ID;MTCN\nRU999;01\n");
        workspace.Run(new AppOptions { CsvDelimiter = ";", DecimalSeparator = ",", ThousandsSeparator = "." });
        Assert.Equal("1.23", workspace.Query("SELECT Commission FROM processed.reinstates_0380")[0][0]);
    }
}
