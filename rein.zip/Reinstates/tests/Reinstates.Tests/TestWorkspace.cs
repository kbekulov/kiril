using System.Data.Common;
using System.Globalization;
using System.Text;
using DuckDB.NET.Data;

namespace Reinstates.Tests;

internal sealed class TestWorkspace : IDisposable
{
    private readonly string root = Path.Combine(Path.GetTempPath(), $"reinstates-test-'quoted;{Guid.NewGuid():N}");
    public string InputDirectory => Path.Combine(root, "input");
    public string DatabasePath => Path.Combine(root, "result.duckdb");

    public TestWorkspace()
    {
        Directory.CreateDirectory(InputDirectory);
        Write("a_0463.csv", "MTCN,Partner ID\n000001,RU999\n");
        Write("b_0463.csv", "Partner ID,MTCN\nFR999,000002\n");
        Write0380("1", "0", "0");
        Write("partners_0458.csv", "Partner ID,MTCN\nRU999,000001\nFR999,000002\nUS999,000003\n");
    }

    public void Write(string name, string content) =>
        File.WriteAllText(Path.Combine(InputDirectory, name), content, new UTF8Encoding(false));

    public void Write0380(string commission, string fx, string total) => Write("reinstates_0380.csv",
        "*** LE Name ***,MTCN,Commission,FX Commission,Total,Extra\n" +
        $"Test LE,000001,{Csv(commission)},{Csv(fx)},{Csv(total)},preserve me\n");

    public void Run(AppOptions? options = null, Action<string>? log = null, CancellationToken token = default) =>
        ProcessingPipeline.Run(InputDirectory, DatabasePath, options ?? new AppOptions(), log, token);

    public string[][] Query(string sql)
    {
        var builder = new DbConnectionStringBuilder { ["DataSource"] = DatabasePath };
        using var connection = new DuckDBConnection(builder.ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();
        command.CommandText = sql;
        using var reader = command.ExecuteReader();
        var rows = new List<string[]>();
        while (reader.Read())
            rows.Add(Enumerable.Range(0, reader.FieldCount).Select(index => reader.IsDBNull(index)
                ? "<NULL>" : Convert.ToString(reader.GetValue(index), CultureInfo.InvariantCulture)!).ToArray());
        return rows.ToArray();
    }

    public long Count(string table) => long.Parse(Query($"SELECT count(*) FROM {table}")[0][0], CultureInfo.InvariantCulture);
    private static string Csv(string value) => "\"" + value.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
    public void Dispose() => Directory.Delete(root, recursive: true);
}
