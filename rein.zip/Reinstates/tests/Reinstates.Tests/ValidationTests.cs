namespace Reinstates.Tests;

public sealed class ValidationTests
{
    [Fact]
    public void RejectsMissingAndExtraMatchingFiles()
    {
        using var workspace = new TestWorkspace();
        File.Delete(Path.Combine(workspace.InputDirectory, "b_0463.csv"));
        Assert.Contains("found 1", Assert.Throws<InvalidDataException>(() => workspace.Run()).Message);
        workspace.Write("b_0463.csv", "ID\n1\n");
        workspace.Write("c_0463.csv", "ID\n2\n");
        Assert.Contains("found 3", Assert.Throws<InvalidDataException>(() => workspace.Run()).Message);
    }

    [Fact]
    public void RejectsOverlappingPatterns()
    {
        using var workspace = new TestWorkspace();
        var options = new AppOptions { Pattern0380 = "a_0463.csv" };
        Assert.Contains("overlap", Assert.Throws<InvalidDataException>(() => workspace.Run(options)).Message);
    }

    [Fact]
    public void SupportsDistinct0463PatternsAndCaseInsensitiveWildcards()
    {
        using var workspace = new TestWorkspace();
        File.Move(Path.Combine(workspace.InputDirectory, "a_0463.csv"), Path.Combine(workspace.InputDirectory, "FIRST_0463.CSV"));
        workspace.Write("unrelated.csv", "ID\n1\n");
        workspace.Run(new AppOptions { Patterns0463 = ["first_*.csv", "b_0463.*"] });
        Assert.Equal(2, workspace.Count("processed.merged_0463"));
    }

    [Theory]
    [InlineData("MTCN,MTCN\n1,2\n")]
    [InlineData("MTCN,mtcn\n1,2\n")]
    [InlineData("MTCN,\n1,2\n")]
    [InlineData("")]
    public void RejectsMissingOrDuplicateHeaders(string content)
    {
        using var workspace = new TestWorkspace();
        workspace.Write("a_0463.csv", content);
        Assert.Throws<InvalidDataException>(() => workspace.Run());
    }

    [Theory]
    [InlineData("Other,MTCN,Commission,FX Commission,Total\nLE,1,1,0,0\n")]
    [InlineData("LE Name,Old LE Name,MTCN,Commission,FX Commission,Total\nLE,LE,1,1,0,0\n")]
    [InlineData("LE Name,MTCN,Commission,FX Commission,Total,Amount\nLE,1,1,0,0,0\n")]
    [InlineData("LE Name,MTCN,Commission,FX Commission,Total,new column\nLE,1,1,0,0,0\n")]
    public void RejectsMissingAmbiguousOrCollidingRequiredColumns(string content)
    {
        using var workspace = new TestWorkspace();
        workspace.Write("reinstates_0380.csv", content);
        Assert.Throws<InvalidDataException>(() => workspace.Run());
    }

    [Theory]
    [InlineData("MTCN,Partner ID\n1,RU999,unexpected\n")]
    [InlineData("MTCN,Partner ID\n1\n")]
    [InlineData("MTCN,Partner ID\n1,\"unterminated\n")]
    public void MalformedCsvFailsAndLeavesPreviousResultsIntact(string content)
    {
        using var workspace = new TestWorkspace();
        workspace.Run();
        workspace.Write("a_0463.csv", content);
        Assert.ThrowsAny<Exception>(() => workspace.Run());
        Assert.Equal("000001", workspace.Query("SELECT MTCN FROM raw.file_0463_a")[0][0]);
    }

    [Fact]
    public void QuotedHeadersAndPartnerIdsAreTreatedAsData()
    {
        using var workspace = new TestWorkspace();
        const string partner = "X'); DROP TABLE raw.file_0463_a; --";
        workspace.Write("a_0463.csv", "MTCN,\"O'Brien \"\"quoted\"\"\"\n01,safe\n");
        workspace.Write("partners_0458.csv", $"Partner ID,MTCN\n{partner},01\n");
        workspace.Run(new AppOptions { AllowedPartnerIds = [partner] });
        Assert.Equal(1, workspace.Count("raw.file_0463_a"));
        Assert.Equal(1, workspace.Count("processed.partners_0458"));
    }

    [Theory]
    [InlineData("{\"AllowedPartnerIds\":null}")]
    [InlineData("{\"AllowedPartnerIds\":[null]}")]
    [InlineData("{\"Patterns0463\":[]}")]
    [InlineData("{\"Pattern0380\":null}")]
    [InlineData("{\"CsvDelimiter\":null}")]
    [InlineData("{\"MinimumAbsoluteCommission\":0}")]
    [InlineData("{\"MinimumAbsoluteDifference\":-0.001}")]
    [InlineData("{\"Threads\":0}")]
    [InlineData("{\"MemoryLimitMb\":1}")]
    [InlineData("{\"DecimalSeparator\":\",\",\"ThousandsSeparator\":\",\"}")]
    [InlineData("{\"UnknownOption\":true}")]
    public void InvalidConfigurationIsRejected(string json)
    {
        using var workspace = new TestWorkspace();
        workspace.Write("settings.json", json);
        Assert.ThrowsAny<Exception>(() => AppOptions.Load(Path.Combine(workspace.InputDirectory, "settings.json")));
    }

    [Fact]
    public void PartialConfigurationRetainsCentralDefaults()
    {
        using var workspace = new TestWorkspace();
        workspace.Write("settings.json", "{\"AllowedPartnerIds\":[\"GB123\"]}");
        var options = AppOptions.Load(Path.Combine(workspace.InputDirectory, "settings.json"));
        Assert.Equal(["GB123"], options.AllowedPartnerIds);
        Assert.Equal(0.001m, options.MinimumAbsoluteCommission);
        Assert.Equal(0.001m, options.MinimumAbsoluteDifference);
    }
}
