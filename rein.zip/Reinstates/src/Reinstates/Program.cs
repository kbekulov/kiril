using System.Data.Common;
using System.Text.Json;
using Reinstates;

if (args.Length == 1 && args[0] is "--help" or "-h")
{
    PrintUsage();
    return 0;
}
if (args.Length is < 1 or > 3 || args[0].StartsWith("--", StringComparison.Ordinal))
{
    PrintUsage();
    return 2;
}

using var cancellation = new CancellationTokenSource();
ConsoleCancelEventHandler cancelHandler = (_, eventArgs) =>
{
    eventArgs.Cancel = true;
    cancellation.Cancel();
};
Console.CancelKeyPress += cancelHandler;
try
{
    var options = AppOptions.Load(args.Length == 3 ? args[2] : null);
    var databasePath = args.Length >= 2 ? args[1] : Path.Combine("output", "reinstates.duckdb");
    ProcessingPipeline.Run(args[0], databasePath, options, Console.WriteLine, cancellation.Token);
    return 0;
}
catch (Exception) when (cancellation.IsCancellationRequested)
{
    Console.Error.WriteLine("Cancelled. The transaction was rolled back; any previous successful datasets remain available.");
    return 130;
}
catch (Exception exception) when (exception is IOException or InvalidDataException or UnauthorizedAccessException or
                                 ArgumentException or JsonException or DbException)
{
    Console.Error.WriteLine($"Error: {exception.Message}");
    Console.Error.WriteLine("The run did not complete. Any previous successful datasets remain available.");
    return 1;
}
finally
{
    Console.CancelKeyPress -= cancelHandler;
}

static void PrintUsage()
{
    Console.WriteLine("Usage: Reinstates <input-directory> [output.duckdb] [settings.json]");
    Console.WriteLine("Defaults: output/reinstates.duckdb; built-in settings unless a JSON path is supplied.");
    Console.WriteLine("Example: dotnet run --project src/Reinstates -- ./samples/input ./output/demo.duckdb ./appsettings.json");
}
