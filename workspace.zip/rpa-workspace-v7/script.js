/* RPA Workspace v7 Signal theme. Vanilla JavaScript, no external runtime dependencies. */
(() => {
  'use strict';
  const config = window.RPA_CONFIG || { links: {}, events: [] };
  // Retained for compatibility with configured destinations from Edition 04.
  const storageKey = 'rpa-workspace:v4:destinations';
  const $ = (selector) => document.querySelector(selector);
  const linkDialog = $('#link-dialog');
  const calendarDialog = $('#calendar-dialog');
  const feedback = $('#link-feedback');
  let editingKey = '';
  let toastTimer;
  let savedLinks = {};

  try {
    const parsed = JSON.parse(localStorage.getItem(storageKey) || '{}');
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) savedLinks = parsed;
  } catch (_) { /* Sandboxed file previews may disable local storage. */ }

  function safeUrl(value) {
    if (typeof value !== 'string' || !value.trim()) return '';
    try {
      const parsed = new URL(value.trim());
      return ['https:', 'http:'].includes(parsed.protocol) ? parsed.href : '';
    } catch (_) { return ''; }
  }

  function resolveUrl(key) {
    return safeUrl(savedLinks[key]) || safeUrl(config.links?.[key]?.url);
  }

  function updateLinks() {
    document.querySelectorAll('[data-resource]').forEach((anchor) => {
      const key = anchor.dataset.resource;
      const entry = config.links?.[key];
      const url = resolveUrl(key);
      anchor.setAttribute('href', url || '#');
      anchor.setAttribute('title', url ? `${entry?.label || key} · ${entry?.destination || 'Resource'}` : `${entry?.label || key} · Set destination`);
      if (url && config.openLinksInNewTab !== false) {
        anchor.target = '_blank';
        anchor.rel = 'noopener noreferrer';
      } else {
        anchor.removeAttribute('target');
        anchor.removeAttribute('rel');
      }
    });
  }

  function toast(message) {
    const node = $('#toast');
    node.textContent = message;
    node.classList.add('visible');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => node.classList.remove('visible'), 3200);
  }

  function openLinkSettings(key) {
    const entry = config.links?.[key];
    if (!entry) { toast('Resource definition is missing from config.js.'); return; }
    editingKey = key;
    $('#link-dialog-title').textContent = entry.label;
    $('#resource-destination').textContent = entry.destination.toUpperCase();
    $('#resource-url').value = resolveUrl(key);
    feedback.textContent = 'Saved only in this browser. Shared defaults belong in config.js.';
    feedback.classList.remove('error');
    linkDialog.showModal();
    $('#resource-url').focus();
  }

  document.querySelectorAll('[data-resource]').forEach((anchor) => {
    anchor.addEventListener('click', (event) => {
      const key = anchor.dataset.resource;
      // Alt + click lets the prototype owner revise an already configured link.
      if (event.altKey || !resolveUrl(key)) {
        event.preventDefault();
        openLinkSettings(key);
      }
    });
  });

  $('#link-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const value = safeUrl($('#resource-url').value);
    if (!value) {
      feedback.textContent = 'Enter a complete http:// or https:// destination.';
      feedback.classList.add('error');
      return;
    }
    savedLinks[editingKey] = value;
    let persisted = true;
    try { localStorage.setItem(storageKey, JSON.stringify(savedLinks)); }
    catch (_) { persisted = false; }
    updateLinks();
    linkDialog.close();
    toast(`${config.links[editingKey].label}: destination ${persisted ? 'saved' : 'set for this session'}. Select the link to open it.`);
  });

  document.querySelectorAll('[data-close]').forEach((button) => {
    button.addEventListener('click', () => document.getElementById(button.dataset.close)?.close());
  });
  [linkDialog, calendarDialog].forEach((dialog) => {
    dialog.addEventListener('click', (event) => {
      if (event.target !== dialog) return;
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) dialog.close();
    });
  });

  // Use local calendar dates, never UTC-parsed date-only strings.
  function localDay(year, month, day) { return new Date(year, month, day, 12, 0, 0, 0); }
  function dayOnly(date) { return localDay(date.getFullYear(), date.getMonth(), date.getDate()); }
  function plusDays(date, count) { return localDay(date.getFullYear(), date.getMonth(), date.getDate() + count); }
  function dateKey(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }
  function parseDate(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
    const [year, month, day] = value.split('-').map(Number);
    const date = localDay(year, month - 1, day);
    return dateKey(date) === value ? date : null;
  }
  function sameDay(a, b) { return dateKey(a) === dateKey(b); }
  function monday(date) { return plusDays(date, -((date.getDay() + 6) % 7)); }
  const fmtMonth = new Intl.DateTimeFormat('en-GB', { month: 'short', year: 'numeric' });
  const fmtLongMonth = new Intl.DateTimeFormat('en-GB', { month: 'long', year: 'numeric' });
  const fmtFull = new Intl.DateTimeFormat('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const fmtDay = new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'short' });
  const weekdayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const today = dayOnly(new Date());
  let selected = today;
  let monthView = localDay(today.getFullYear(), today.getMonth(), 1);
  const events = (Array.isArray(config.events) ? config.events : []).flatMap((entry) => {
    const start = parseDate(entry.start);
    const end = parseDate(entry.end || entry.start);
    if (!start || !end || end < start || typeof entry.title !== 'string') return [];
    return [{ ...entry, startDate: start, endDate: end }];
  });
  function eventsBetween(start, end) {
    return events.filter((entry) => entry.startDate <= end && entry.endDate >= start)
      .sort((a, b) => a.startDate - b.startDate);
  }
  function makeIcon(name) {
    const node = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    node.setAttribute('class', 'icon');
    node.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', `#i-${name}`);
    node.appendChild(use);
    return node;
  }
  function dayButton(date, withWeekday, outside = false) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'day-button';
    button.dataset.date = dateKey(date);
    button.setAttribute('aria-label', fmtFull.format(date));
    button.setAttribute('aria-pressed', String(sameDay(date, selected)));
    if (sameDay(date, today)) {
      button.classList.add('is-today');
      button.setAttribute('aria-current', 'date');
    }
    if (sameDay(date, selected)) button.classList.add('is-selected');
    if (outside) button.classList.add('is-outside');
    const dayEvents = eventsBetween(date, date);
    if (dayEvents.length) {
      button.classList.add('has-event');
      button.title = `${fmtFull.format(date)}: ${dayEvents.map((entry) => entry.title + (entry.referenceOnly ? ' (reference entry)' : '')).join('; ')}`;
      button.setAttribute('aria-label', button.title);
    }
    if (withWeekday) {
      const label = document.createElement('span');
      label.className = 'weekday';
      label.textContent = weekdayLabels[(date.getDay() + 6) % 7];
      button.appendChild(label);
    }
    const number = document.createElement('span');
    number.className = 'day-number';
    number.textContent = String(date.getDate());
    button.appendChild(number);
    button.addEventListener('click', () => {
      selected = date;
      renderWeek();
      if (calendarDialog.open) {
        monthView = localDay(selected.getFullYear(), selected.getMonth(), 1);
        renderMonth();
        document.querySelector(`#month-grid [data-date="${dateKey(date)}"]`)?.focus();
      } else {
        document.querySelector(`#week-grid [data-date="${dateKey(date)}"]`)?.focus();
      }
    });
    return button;
  }

  function renderWeek() {
    const first = monday(selected);
    const last = plusDays(first, 6);
    const grid = $('#week-grid');
    grid.replaceChildren(...Array.from({ length: 7 }, (_, index) => dayButton(plusDays(first, index), true)));
    $('#week-month').textContent = fmtMonth.format(selected);
    grid.setAttribute('aria-label', `Week of ${fmtDay.format(first)} to ${fmtDay.format(last)}`);
    const inWeek = eventsBetween(first, last);
    const onDay = eventsBetween(selected, selected);
    const summary = $('#week-summary');
    summary.replaceChildren(makeIcon(inWeek.length ? 'calendar' : 'info'));
    const text = document.createElement('span');
    if (onDay.length) {
      text.textContent = onDay.length > 1 ? `${onDay.length} configured events on ${fmtDay.format(selected)}` : `${onDay[0].title}${onDay[0].referenceOnly ? ' · reference' : ''}`;
    } else if (inWeek.length) {
      text.textContent = `${inWeek.length} configured event${inWeek.length === 1 ? '' : 's'} this week`;
    } else {
      text.textContent = 'No events entered this week.';
    }
    summary.appendChild(text);
    summary.title = 'Configured events only. No live calendar connection.';
  }

  function renderMonth() {
    $('#month-title').textContent = fmtLongMonth.format(monthView);
    const first = monday(monthView);
    $('#month-grid').replaceChildren(...Array.from({ length: 42 }, (_, index) => {
      const date = plusDays(first, index);
      return dayButton(date, false, date.getMonth() !== monthView.getMonth());
    }));
    const start = localDay(monthView.getFullYear(), monthView.getMonth(), 1);
    const end = localDay(monthView.getFullYear(), monthView.getMonth() + 1, 0);
    const inMonth = eventsBetween(start, end);
    const list = $('#month-events');
    list.replaceChildren();
    if (!inMonth.length) {
      list.textContent = 'No events have been entered for this month.';
      return;
    }
    for (const entry of inMonth) {
      const row = document.createElement('div');
      row.className = 'month-event';
      const dates = document.createElement('span');
      dates.className = 'month-event-date';
      dates.textContent = sameDay(entry.startDate, entry.endDate) ? fmtDay.format(entry.startDate) : `${fmtDay.format(entry.startDate)} to ${fmtDay.format(entry.endDate)}`;
      const copy = document.createElement('span');
      const title = document.createElement('strong');
      title.textContent = entry.title;
      const note = document.createElement('small');
      note.textContent = entry.referenceOnly ? 'Reference from the supplied screenshot. Verify before use.' : 'Configured team event';
      copy.append(title, note);
      row.append(dates, copy);
      list.appendChild(row);
    }
  }

  $('#prev-week').addEventListener('click', () => { selected = plusDays(selected, -7); renderWeek(); });
  $('#next-week').addEventListener('click', () => { selected = plusDays(selected, 7); renderWeek(); });
  $('#today').addEventListener('click', () => { selected = dayOnly(new Date()); renderWeek(); });
  $('#open-calendar').addEventListener('click', () => {
    monthView = localDay(selected.getFullYear(), selected.getMonth(), 1);
    renderMonth();
    calendarDialog.showModal();
  });
  $('#prev-month').addEventListener('click', () => { monthView = localDay(monthView.getFullYear(), monthView.getMonth() - 1, 1); renderMonth(); });
  $('#next-month').addEventListener('click', () => { monthView = localDay(monthView.getFullYear(), monthView.getMonth() + 1, 1); renderMonth(); });
  $('#month-today').addEventListener('click', () => {
    const now = new Date();
    monthView = localDay(now.getFullYear(), now.getMonth(), 1);
    selected = dayOnly(now);
    renderWeek(); renderMonth();
  });
  // Arrow keys navigate day controls without requiring a mouse.
  [$('#week-grid'), $('#month-grid')].forEach((grid) => {
    grid.addEventListener('keydown', (event) => {
      if (!event.target.matches('.day-button')) return;
      const moves = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 };
      if (!(event.key in moves)) return;
      event.preventDefault();
      const current = parseDate(event.target.dataset.date);
      selected = plusDays(current, moves[event.key]);
      if (grid.id === 'month-grid') {
        monthView = localDay(selected.getFullYear(), selected.getMonth(), 1);
        renderMonth();
      }
      renderWeek();
      grid.querySelector(`[data-date="${dateKey(selected)}"]`)?.focus();
    });
  });

  updateLinks();
  renderWeek();
  window.RPA_WORKSPACE = Object.freeze({ version: config.version, resourceCount: Object.keys(config.links || {}).length });
})();
