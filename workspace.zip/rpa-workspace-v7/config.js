/* Internal URLs are intentionally empty. Supply your actual destinations here.
 * One canonical entry per destination; guide/tool pairs share a visible resource row.
 * Event end dates are inclusive. referenceOnly entries come from the supplied screenshots, not a live calendar.
 */
window.RPA_CONFIG = {
  "version": "7.0.0",
  "openLinksInNewTab": true,
  "links": {
    "sn-normal": {
      "label": "ServiceNow Normal",
      "destination": "ServiceNow",
      "url": ""
    },
    "sn-standard": {
      "label": "ServiceNow Standard",
      "destination": "ServiceNow",
      "url": ""
    },
    "sn-expiring": {
      "label": "Expiring Changes",
      "destination": "ServiceNow",
      "url": ""
    },
    "workflow": {
      "label": "Project Workflow",
      "destination": "Confluence",
      "url": ""
    },
    "squads": {
      "label": "Squads",
      "destination": "Confluence",
      "url": ""
    },
    "ownership": {
      "label": "Process Ownership",
      "destination": "Confluence",
      "url": ""
    },
    "chapters": {
      "label": "Chapters",
      "destination": "Confluence",
      "url": ""
    },
    "bp-code": {
      "label": "BP Coding Standards",
      "destination": "Confluence",
      "url": ""
    },
    "uipath-code": {
      "label": "UiPath Coding Standards",
      "destination": "Confluence",
      "url": ""
    },
    "qa": {
      "label": "QA Documents",
      "destination": "Confluence",
      "url": ""
    },
    "release": {
      "label": "Release Management",
      "destination": "Confluence",
      "url": ""
    },
    "handbook": {
      "label": "Operations Handbook",
      "destination": "Confluence",
      "url": ""
    },
    "bp-maintenance": {
      "label": "BP Maintenance",
      "destination": "Confluence",
      "url": ""
    },
    "uipath-maintenance": {
      "label": "UiPath Maintenance",
      "destination": "Confluence",
      "url": ""
    },
    "master-report": {
      "label": "RPA Master Report",
      "destination": "Confluence",
      "url": ""
    },
    "jira-maintenance": {
      "label": "RPA Maintenance",
      "destination": "Jira board",
      "url": ""
    },
    "jira-atom": {
      "label": "SCRUM ATOM",
      "destination": "Jira board",
      "url": ""
    },
    "jira-awesom-o": {
      "label": "SCRUM AWESOM-O",
      "destination": "Jira board",
      "url": ""
    },
    "jira-baymax": {
      "label": "SCRUM BAYMAX",
      "destination": "Jira board",
      "url": ""
    },
    "jira-bender": {
      "label": "SCRUM BENDER",
      "destination": "Jira board",
      "url": ""
    },
    "jira-jarvis": {
      "label": "SCRUM JARVIS",
      "destination": "Jira board",
      "url": ""
    },
    "jira-wall-e": {
      "label": "SCRUM WALL-E",
      "destination": "Jira board",
      "url": ""
    },
    "sharepoint": {
      "label": "Robotics Team SharePoint",
      "destination": "Platform / resource",
      "url": ""
    },
    "uipath-cloud": {
      "label": "UiPath Cloud",
      "destination": "Platform / resource",
      "url": ""
    },
    "power-bi": {
      "label": "Power BI",
      "destination": "Platform / resource",
      "url": ""
    },
    "sla": {
      "label": "RPA Robots SLA and Benefits List",
      "destination": "Platform / resource",
      "url": ""
    },
    "project-sop": {
      "label": "Automation Project Implementation SOP",
      "destination": "Confluence",
      "url": ""
    },
    "incident": {
      "label": "Incident Management SOP (Maintenance)",
      "destination": "Confluence",
      "url": ""
    },
    "requests": {
      "label": "ISRA, ARB, RPA Request SOP",
      "destination": "Confluence",
      "url": ""
    },
    "alerts-guide": {
      "label": "Data Driven Alerts Guide",
      "destination": "Confluence",
      "url": ""
    },
    "alerts-tool": {
      "label": "Data Driven Alerts Tool",
      "destination": "Operational tool",
      "url": ""
    },
    "launcher-guide": {
      "label": "BP Schedule Launcher Guide",
      "destination": "Confluence",
      "url": ""
    },
    "launcher-tool": {
      "label": "BP Schedule Launcher Tool",
      "destination": "Operational tool",
      "url": ""
    }
  },
  "events": [
    {
      "id": "reference-amira-sep-2026",
      "title": "Amira's holidays",
      "start": "2026-09-11",
      "end": "2026-09-25",
      "referenceOnly": true
    }
  ]
};
