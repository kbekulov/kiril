using System.Text.RegularExpressions;

namespace Reinstates.Processing;

public sealed class Process0380Step(AppOptions options) : IPipelineStep
{
    private const string Source = "raw.file_0380";
    private const string DecimalType = "DECIMAL(38, 12)";
    public string Name => "Processing 0380";

    public void Execute(Database database, Action<string> log)
    {
        var columns = database.Columns(Source);
        var leName = ColumnNames.Require(columns, "LE Name", Source, contains: true);
        var mtcn = ColumnNames.Require(columns, "MTCN", Source);
        var total = ColumnNames.Require(columns, "Total", Source);
        var commission = ColumnNames.Require(columns, "Commission", Source);
        var fxCommission = ColumnNames.Require(columns, "FX Commission", Source);
        var renamed = new Dictionary<string, string>
        {
            [leName] = "LE Name",
            [mtcn] = "MTCN (Reinstates)",
            [total] = "Amount",
            [commission] = "Commission",
            [fxCommission] = "FX Commission"
        };
        var outputNames = columns.Select(column => renamed.GetValueOrDefault(column, column)).ToArray();
        if (outputNames.Distinct(StringComparer.OrdinalIgnoreCase).Count() != columns.Count ||
            outputNames.Contains("new column", StringComparer.OrdinalIgnoreCase))
            throw new InvalidDataException("0380: renaming would produce duplicate columns, or the reserved 'new column' already exists.");
        string[] numericColumns = [commission, fxCommission, total];
        foreach (var column in numericColumns)
            ValidateNumbers(database, column);
        var projection = string.Join(",\n", columns.Select(column =>
            $"{(numericColumns.Contains(column) ? Number(column) : Database.Identifier(column))} " +
            $"AS {Database.Identifier(renamed.GetValueOrDefault(column, column))}"));
        var originalCount = database.Count($"SELECT count(*) FROM {Source}");
        var afterCommission = database.Count($"""
            SELECT count(*) FROM {Source}
            WHERE abs({Number(commission)}) >= CAST($minimum AS {DecimalType})
            """, ("minimum", options.MinimumAbsoluteCommission));
        // DECIMAL arithmetic avoids binary floating-point errors at the rounding boundaries.
        // The temporary column exists only inside this query; it is not persisted.
        database.Execute($"""
            CREATE OR REPLACE TABLE processed.reinstates_0380 AS
            WITH typed AS (
                SELECT {projection} FROM {Source}
            ), calculated AS (
                SELECT *, round("Commission" + "FX Commission" - "Amount", 2) AS "new column"
                FROM typed
                WHERE abs("Commission") >= CAST($commission_minimum AS {DecimalType})
            )
            SELECT * EXCLUDE ("new column") REPLACE (CAST("Commission" AS DOUBLE) AS "Commission")
            FROM calculated
            WHERE abs("new column") >= CAST($difference_minimum AS {DecimalType})
            """, ("commission_minimum", options.MinimumAbsoluteCommission),
            ("difference_minimum", options.MinimumAbsoluteDifference));
        var remaining = database.Count("SELECT count(*) FROM processed.reinstates_0380");
        log($"  Commission filter removed {originalCount - afterCommission:N0}; rounded-difference filter removed {afterCommission - remaining:N0}.");
        log($"  processed.reinstates_0380: {remaining:N0} rows");
    }

    private string NormalizedNumber(string column)
    {
        var expression = $"trim({Database.Identifier(column)})";
        if (options.ThousandsSeparator.Length > 0)
            expression = $"replace({expression}, {Database.Literal(options.ThousandsSeparator)}, '')";
        if (options.DecimalSeparator != ".")
            expression = $"replace({expression}, {Database.Literal(options.DecimalSeparator)}, '.')";
        return expression;
    }

    private string Number(string column) => $"CAST({NormalizedNumber(column)} AS {DecimalType})";

    private void ValidateNumbers(Database database, string column)
    {
        var separator = Regex.Escape(options.DecimalSeparator);
        var integer = options.ThousandsSeparator.Length == 0
            ? "[0-9]+"
            : $"([0-9]+|[0-9]{{1,3}}({Regex.Escape(options.ThousandsSeparator)}[0-9]{{3}})+)";
        var pattern = $"[+-]?({integer}({separator}[0-9]{{0,12}})?|{separator}[0-9]{{1,12}})";
        var invalidCount = database.Count($"""
            SELECT count(*) FROM {Source}
            WHERE {Database.Identifier(column)} IS NULL
               OR NOT regexp_full_match(trim({Database.Identifier(column)}), $pattern)
               OR TRY_CAST({NormalizedNumber(column)} AS {DecimalType}) IS NULL
            """, ("pattern", pattern));
        if (invalidCount > 0)
            throw new InvalidDataException(
                $"0380: column '{column}' has {invalidCount:N0} missing, invalid, or out-of-range numeric value(s). " +
                $"Expected decimal separator '{options.DecimalSeparator}', thousands separator '{options.ThousandsSeparator}', " +
                "at most 26 integer and 12 fractional digits. Scientific notation and currency symbols are not accepted. " +
                "Correct the input or number-format settings; no changes will be committed.");
    }
}
