using System.Text;
using Microsoft.VisualBasic.FileIO;

namespace Reinstates.Processing;

public sealed class ImportCsvStep(InputFiles files, AppOptions options) : IPipelineStep
{
    public string Name => "Importing four CSV files";

    public void Execute(Database database, Action<string> log)
    {
        Import(files.First0463, "raw.file_0463_a");
        Import(files.Second0463, "raw.file_0463_b");
        Import(files.File0380, "raw.file_0380");
        Import(files.File0458, "raw.file_0458");

        void Import(string path, string table)
        {
            var headers = ReadHeaders(path, options.CsvDelimiter);
            var columns = string.Join(", ", headers.Select(header => $"{Database.Literal(header)}: 'VARCHAR'"));
            // Read one selected path, not a new glob; retain IDs, leading zeroes and all extra columns.
            database.Execute($$"""
                CREATE OR REPLACE TABLE {{table}} AS
                SELECT * FROM read_csv($path,
                    header = true, auto_detect = false, delim = $delimiter,
                    quote = '"', escape = '"', columns = {{{columns}}},
                    encoding = 'utf-8', strict_mode = true, ignore_errors = false,
                    null_padding = false, hive_partitioning = false)
                """, ("path", path), ("delimiter", options.CsvDelimiter));
            log($"  {Path.GetFileName(path)} -> {table}: {database.Count($"SELECT count(*) FROM {table}"):N0} rows");
        }
    }

    private static string[] ReadHeaders(string path, string delimiter)
    {
        // Only the header is read into .NET. TextFieldParser handles quoted/multiline CSV fields.
        using var reader = new StreamReader(path, new UTF8Encoding(false, true));
        using var parser = new TextFieldParser(reader)
        {
            TextFieldType = FieldType.Delimited,
            HasFieldsEnclosedInQuotes = true,
            TrimWhiteSpace = false
        };
        parser.SetDelimiters(delimiter);
        string[] headers;
        try
        {
            headers = parser.ReadFields() ?? throw new InvalidDataException($"'{path}' has no CSV header.");
        }
        catch (MalformedLineException exception)
        {
            throw new InvalidDataException($"'{path}' has a malformed CSV header.", exception);
        }
        if (headers.Any(string.IsNullOrWhiteSpace) || headers.Any(header => header.Contains('\0')))
            throw new InvalidDataException($"'{path}' has an empty or invalid column name.");
        if (headers.Distinct(StringComparer.OrdinalIgnoreCase).Count() != headers.Length)
            throw new InvalidDataException($"'{path}' has duplicate column names (case-insensitive).");
        return headers;
    }
}
