using System.Text.Json;
using System.Text.Json.Serialization;

namespace Reinstates;

/// <summary>Central defaults; an optional JSON file can override individual settings.</summary>
public sealed record AppOptions
{
    public string[] Patterns0463 { get; init; } = ["*0463*.csv"];
    public string Pattern0380 { get; init; } = "*0380*.csv";
    public string Pattern0458 { get; init; } = "*0458*.csv";
    public string[] AllowedPartnerIds { get; init; } = ["RU999", "FR999"];
    public decimal MinimumAbsoluteCommission { get; init; } = 0.001m;
    public decimal MinimumAbsoluteDifference { get; init; } = 0.001m;
    public string CsvDelimiter { get; init; } = ",";
    public string DecimalSeparator { get; init; } = ".";
    public string ThousandsSeparator { get; init; } = ",";
    public int MemoryLimitMb { get; init; } = 1024;
    public int Threads { get; init; } = 2;

    public static AppOptions Load(string? path)
    {
        var options = path is null
            ? new AppOptions()
            : JsonSerializer.Deserialize<AppOptions>(File.ReadAllText(path), new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow
            }) ?? throw new InvalidDataException("The configuration must be a JSON object.");
        options.Validate();
        return options;
    }

    public void Validate()
    {
        if (Patterns0463 is not { Length: > 0 })
            throw new ArgumentException("Patterns0463 must contain at least one filename pattern.");
        foreach (var pattern in Patterns0463.Append(Pattern0380).Append(Pattern0458))
        {
            if (string.IsNullOrWhiteSpace(pattern) || pattern.IndexOfAny(['/', '\\']) >= 0)
                throw new ArgumentException("File patterns must be nonempty filenames, without directories.");
        }
        if (AllowedPartnerIds is null || AllowedPartnerIds.Any(string.IsNullOrWhiteSpace))
            throw new ArgumentException("AllowedPartnerIds must be an array of nonempty IDs (or [] to keep no partners).");
        if (MinimumAbsoluteCommission <= 0 || MinimumAbsoluteDifference <= 0 ||
            decimal.Round(MinimumAbsoluteCommission, 12) != MinimumAbsoluteCommission ||
            decimal.Round(MinimumAbsoluteDifference, 12) != MinimumAbsoluteDifference ||
            MinimumAbsoluteCommission >= 100000000000000000000000000m ||
            MinimumAbsoluteDifference >= 100000000000000000000000000m)
            throw new ArgumentException("Thresholds must be positive, with at most 26 integer and 12 fractional digits.");
        if (CsvDelimiter is not { Length: 1 } || CsvDelimiter[0] is '"' or '\r' or '\n' or '\0')
            throw new ArgumentException("CsvDelimiter must be one character, other than a quote, newline or NUL.");
        if (DecimalSeparator is not ("." or ","))
            throw new ArgumentException("DecimalSeparator must be '.' or ','.");
        if (ThousandsSeparator is not ("" or "," or "." or " ") || ThousandsSeparator == DecimalSeparator)
            throw new ArgumentException("ThousandsSeparator must be empty, ',', '.', or a space, and differ from DecimalSeparator.");
        if (MemoryLimitMb < 128 || Threads < 1)
            throw new ArgumentException("MemoryLimitMb must be at least 128, and Threads must be at least 1.");
    }
}
