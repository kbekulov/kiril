using System.Data.Common;
using System.Globalization;
using DuckDB.NET.Data;

namespace Reinstates;

/// <summary>One connection per run. Large datasets stay inside DuckDB, not in managed collections.</summary>
public sealed class Database : IDisposable
{
    private readonly DuckDBConnection connection;
    private readonly CancellationToken cancellationToken;

    public Database(string path, AppOptions options, CancellationToken cancellationToken = default)
    {
        this.cancellationToken = cancellationToken;
        var builder = new DbConnectionStringBuilder { ["DataSource"] = path };
        connection = new DuckDBConnection(builder.ConnectionString);
        try
        {
            connection.Open();
            Execute("SET memory_limit = $limit", ("limit", $"{options.MemoryLimitMb}MB"));
            Execute("SET threads = $threads", ("threads", options.Threads));
            Execute("SET preserve_insertion_order = false");
        }
        catch
        {
            connection.Dispose();
            throw;
        }
    }

    public void Execute(string sql, params (string Name, object Value)[] parameters)
    {
        cancellationToken.ThrowIfCancellationRequested();
        using var command = CreateCommand(sql, parameters);
        using var registration = cancellationToken.Register(command.Cancel);
        command.ExecuteNonQuery();
    }

    public long Count(string sql, params (string Name, object Value)[] parameters)
    {
        cancellationToken.ThrowIfCancellationRequested();
        using var command = CreateCommand(sql, parameters);
        using var registration = cancellationToken.Register(command.Cancel);
        return Convert.ToInt64(command.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    public IReadOnlyList<string> Columns(string table)
    {
        using var command = CreateCommand($"SELECT * FROM {table} LIMIT 0", []);
        using var reader = command.ExecuteReader();
        return Enumerable.Range(0, reader.FieldCount).Select(reader.GetName).ToArray();
    }

    public void InTransaction(Action action)
    {
        using var transaction = connection.BeginTransaction();
        action();
        cancellationToken.ThrowIfCancellationRequested();
        transaction.Commit();
        // Dispose rolls back on failure, including cancellation.
    }

    private DuckDBCommand CreateCommand(string sql, (string Name, object Value)[] parameters)
    {
        var command = connection.CreateCommand();
        command.CommandText = sql;
        foreach (var (name, value) in parameters)
            command.Parameters.Add(new DuckDBParameter(name, value));
        return command;
    }

    // Parameters cannot represent identifiers or the CSV columns struct. Escape those centrally.
    public static string Identifier(string name) => "\"" + name.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
    public static string Literal(string value) => "'" + value.Replace("'", "''", StringComparison.Ordinal) + "'";
    public void Dispose() => connection.Dispose();
}
