using System.Diagnostics;
using Reinstates.Processing;

namespace Reinstates;

public static class ProcessingPipeline
{
    public static void Run(
        string inputDirectory,
        string databasePath,
        AppOptions options,
        Action<string>? log = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        options.Validate();
        var files = InputFiles.Discover(inputDirectory, options);
        databasePath = Path.GetFullPath(databasePath);
        if (!databasePath.EndsWith(".duckdb", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("The output database filename must end with .duckdb.");
        Directory.CreateDirectory(Path.GetDirectoryName(databasePath)!);
        log ??= _ => { };
        IPipelineStep[] steps =
        [
            new ImportCsvStep(files, options),
            new Merge0463Step(),
            new Process0380Step(options),
            new Process0458Step(options)
        ];
        using var database = new Database(databasePath, options, cancellationToken);
        database.InTransaction(() =>
        {
            database.Execute("CREATE SCHEMA IF NOT EXISTS raw");
            database.Execute("CREATE SCHEMA IF NOT EXISTS processed");
            foreach (var step in steps)
            {
                cancellationToken.ThrowIfCancellationRequested();
                log($"{step.Name}...");
                var stopwatch = Stopwatch.StartNew();
                step.Execute(database, log);
                log($"  Finished in {stopwatch.Elapsed.TotalSeconds:F2}s (pending commit).");
            }
        });
        log($"Committed all datasets to {databasePath}");
    }
}
