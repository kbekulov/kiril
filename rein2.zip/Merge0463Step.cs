namespace Reinstates.Processing;

public sealed class Merge0463Step : IPipelineStep
{
    public string Name => "Combining the 0463 datasets";

    public void Execute(Database database, Action<string> log)
    {
        // Append rows, keep duplicates, align columns by name and fill absent columns with NULL.
        database.Execute("""
            CREATE OR REPLACE TABLE processed.merged_0463 AS
            SELECT * FROM raw.file_0463_a
            UNION ALL BY NAME
            SELECT * FROM raw.file_0463_b
            """);
        log($"  processed.merged_0463: {database.Count("SELECT count(*) FROM processed.merged_0463"):N0} rows");
    }
}
