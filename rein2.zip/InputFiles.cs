using System.IO.Enumeration;

namespace Reinstates;

public sealed record InputFiles(string First0463, string Second0463, string File0380, string File0458)
{
    public static InputFiles Discover(string directory, AppOptions options)
    {
        options.Validate();
        directory = Path.GetFullPath(directory);
        if (!Directory.Exists(directory))
            throw new DirectoryNotFoundException($"Input directory does not exist: {directory}");
        var paths = Directory.EnumerateFiles(directory).Order(StringComparer.Ordinal).ToArray();
        var files0463 = Find(options.Patterns0463, 2, "0463");
        var file0380 = Find([options.Pattern0380], 1, "0380")[0];
        var file0458 = Find([options.Pattern0458], 1, "0458")[0];
        var selected = files0463.Concat([file0380, file0458]).ToArray();
        if (selected.Distinct(StringComparer.Ordinal).Count() != 4)
            throw new InvalidDataException("The filename patterns overlap: each of the four inputs must be a different file.");
        return new InputFiles(files0463[0], files0463[1], file0380, file0458);

        string[] Find(string[] patterns, int expected, string label)
        {
            var matches = paths.Where(path => patterns.Any(pattern =>
                FileSystemName.MatchesSimpleExpression(pattern, Path.GetFileName(path), ignoreCase: true))).ToArray();
            if (matches.Length != expected)
                throw new InvalidDataException(
                    $"Expected exactly {expected} {label} file(s) matching [{string.Join(", ", patterns)}] in '{directory}', " +
                    $"but found {matches.Length}. Check the patterns and remove obsolete matching files.");
            return matches;
        }
    }
}
