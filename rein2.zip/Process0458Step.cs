namespace Reinstates.Processing;

public sealed class Process0458Step(AppOptions options) : IPipelineStep
{
    public string Name => "Filtering 0458 partners";

    public void Execute(Database database, Action<string> log)
    {
        var partnerColumn = ColumnNames.Require(database.Columns("raw.file_0458"), "Partner ID", "0458");
        database.Execute("CREATE OR REPLACE TABLE processed.allowed_partners (partner_id VARCHAR PRIMARY KEY)");
        foreach (var id in options.AllowedPartnerIds.Select(id => id.Trim().ToUpperInvariant()).Distinct(StringComparer.Ordinal))
            database.Execute("INSERT INTO processed.allowed_partners VALUES ($id)", ("id", id));
        database.Execute($"""
            CREATE OR REPLACE TABLE processed.partners_0458 AS
            SELECT source.* FROM raw.file_0458 AS source
            WHERE EXISTS (
                SELECT 1 FROM processed.allowed_partners AS allowed
                WHERE allowed.partner_id = upper(trim(source.{Database.Identifier(partnerColumn)}))
            )
            """);
        var before = database.Count("SELECT count(*) FROM raw.file_0458");
        var after = database.Count("SELECT count(*) FROM processed.partners_0458");
        log($"  processed.partners_0458: {after:N0} rows kept; {before - after:N0} removed.");
    }
}
