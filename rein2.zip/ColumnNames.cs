using System.Globalization;
using System.Text;

namespace Reinstates.Processing;

internal static class ColumnNames
{
    public static string Require(IReadOnlyList<string> columns, string expected, string table, bool contains = false)
    {
        var matches = columns.Where(column => contains
            ? Normalize(column).Contains(expected, StringComparison.OrdinalIgnoreCase)
            : Normalize(column).Equals(expected, StringComparison.OrdinalIgnoreCase)).ToArray();
        return matches.Length == 1 ? matches[0] : throw new InvalidDataException(
            $"{table}: expected exactly one column {(contains ? "containing" : "named")} '{expected}', found {matches.Length}.");
    }

    private static string Normalize(string value)
    {
        var visible = new string(value.Normalize(NormalizationForm.FormKC)
            .Where(character => char.GetUnicodeCategory(character) != UnicodeCategory.Format).ToArray());
        return string.Join(' ', visible.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries));
    }
}
