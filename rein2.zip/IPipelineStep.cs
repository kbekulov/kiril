namespace Reinstates.Processing;

public interface IPipelineStep
{
    string Name { get; }
    void Execute(Database database, Action<string> log);
}
